window._config = {
    cognito: {
        userPoolId: 'us-east-1_dpw0FhXZj', // e.g. us-east-2_uXboG5pAb
        userPoolClientId: '4750vt2c5m744v871nlu5p89gj', // e.g. 25ddkmj4v6hfsfvruhpfi7n4hv
        region: 'us-east-1' // e.g. us-east-2
    },
    api: {
        invokeUrl: 'https://911goderil.execute-api.us-east-1.amazonaws.com/Dev' // e.g. https://rc7nyt4tql.execute-api.us-west-2.amazonaws.com/prod',
    }
};
